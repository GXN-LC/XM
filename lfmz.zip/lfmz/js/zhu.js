$(function() {
	$(".zhuce").click(function() {
		var phones = document.getElementById("phone");
		if(phones.validity.valueMissing == true) {
			phones.setCustomValidity("请输入手机号");
		} else if(phones.validity.patternMismatch == true) {
			phones.setCustomValidity("手机号格式不正确");
		} else {
			phones.setCustomValidity("");
		}

		var mima = document.getElementById("pass");
		if(mima.validity.valueMissing == true) {
			mima.setCustomValidity("请输入密码");
		} else if(mima.validity.patternMismatch == true) {
			mima.setCustomValidity("密码格式不正确");
		} else {
			mima.setCustomValidity("");
		}

		var zaishu = document.getElementById("passes");
		if(zaishu.validity.valueMissing == true) {
			zaishu.setCustomValidity("请再次输入密码");
		} else if(zaishu.value != mima.value) {
			zaishu.setCustomValidity("两次密码不一致");
		} else {
			zaishu.setCustomValidity("");
		}
	})
})