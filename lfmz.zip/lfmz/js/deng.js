$(function() {
	$("#zhangh").blur(function() {
		var zhangh = $(this).val();
		if(zhangh == "") {
			$(".zhang").html("请输入用户名");
		} else {
			$(".zhang").html("");
		}
	})
	$("#password").blur(function() {
		var password = $(this).val();
		if(password == "") {
			$(".pass").html("请输入密码");
		} else {
			$(".pass").html("");
		}
	})
	$("#dengs").click(function() {
		 var zhh=$("#zhangh").val();	
		 if(zhh==""){
		 	 $(".zhang").html("请输入用户名");
		 	 return false;
		 }else{
		 	$(".zhang").html("");
		 }
		  var mim=$("#password").val();
		 if(mim==""){
		 	$(".pass").html("请输入密码");
		 	return false;
		 }else{
		 	$(".pass").html("");
		 }
		 return true;
	})
	
	
})
/*function deng (){
		var zhh=$("#zhangh").val();
	      ajax('js/ajax123.json',function(str){
	        //将JSON 数据来生成原生的 JavaScript 对象
	        var arr=eval(str);
	        for (i = 0;i<arr.length;i++) {
	        	if(arr[i].tag_name == zhh){
	        		alert("登录成功！");
	        	}else{
	        		alert("失败");
	        	}
	        }
	    });
    
}
function ajax(url, fnSucc, fnFaild)
{
  //1.创建Ajax对象
  var oAjax=null;
 
  if(window.XMLHttpRequest)
  {
    oAjax=new XMLHttpRequest();
  }
  else
  {
    oAjax=new ActiveXObject("Microsoft.XMLHTTP");
  }
 
  //2.连接服务器
  oAjax.open('GET', url, true);
 
  //3.发送请求
  oAjax.send();
 
  //4.接收服务器的返回
  oAjax.onreadystatechange=function ()
  {
    if(oAjax.readyState==4) //完成
    {
      if(oAjax.status==200)  //成功
      {
        fnSucc(oAjax.responseText);
      }
      else
      {
        if(fnFaild)
          fnFaild(oAjax.status);
      }
    }
  };
}*/