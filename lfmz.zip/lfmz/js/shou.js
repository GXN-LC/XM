$(function(){
	var a;
	var index=0;
	a=setInterval(play,3000);
	var i = $("#lunbo").children().children().length;
	function play(){
		index++;
		if(index>i){
			index=0;
		}
		$("#lunbo ul li:eq("+index+")").fadeIn(	1000).siblings().fadeOut(1000);
	}
	$("[name=ssuo]").focus(function(){
		var gb=$(this).val();
		if(gb=="搜商品"){
		  $(this).val("");
		}
	});
	$("[name=ssuo]").blur(function(){
		var gb=$(this).val();
		if(gb==""){
			$(this).val("搜商品");
		}
	});
	$(".hufu").each(function(i){
		$(this).mouseover(function(){
			$("#hufupin"+i).show();
		});
		$(this).mouseout(function(){
			$("#hufupin"+i).hide();
		});
	});
	$(".ding").mousemove(function(){
		$(".dingdan").show();
	})
	$(".ding").mouseout(function(){
		$(".dingdan").hide();
	})
	
	$(".gw").hide();
	$(".sy_l_yps").each(function(i){
		$(this).mouseover(function(){
			$("#gw"+i).show();
		});
		$(this).mouseout(function(){
			$("#gw"+i).hide();
		})
	})
})
