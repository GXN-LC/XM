$(function(){
	suan();
	shangp();
	function suan(){
		var zongjia=0;
		$(".dingd_s").each(function(i,dom){	
			var shu=$(dom).children("ul").children(".dingd1_sl2").find(".button_z").val();
			//计算小计
			var price=shu*$(dom).children("ul").children(".dingd1_wz21").find("span").text();
			//总计
			$(dom).children("ul").children(".dingd1_wz23").find("span").html(parseFloat(price));
			zongjia+=price;
		});
		   $(".zonji").text(zongjia);
		}
		$(".button_jn").click(function(){
			var jia=$(this).prev().val();
			$(this).prev().val(parseInt(jia)+1);
			suan();
		});
		$(".button_ja").click(function(){
			var jian=$(this).next().val();
			if(jian>1){
			  $(this).next().val(parseInt(jian)-1);
			  suan();
			}else{
				alert("不能再减了！");
			}
		});
	   $("#fuxuan").click(function(){
	   	  $("[name=xuan]").each(function(){
	   	  	this.checked=$("#fuxuan")[0].checked;
	   	  });
	   })
	   $("#fuxuans").click(function(){
	   	$("[name=xuan]").each(function(){
	   		this.checked=$("#fuxuans")[0].checked;
	   	});
	   })
		$(".shanc").click(function(){
			$(".shanc").parent().parent().parent().remove();
			 suan();
			 shangp();
		})
		$(".shancs").click(function(){
			$(".shancs").parent().parent().parent().remove();
			 suan();
			 shangp();
		});
         $(".plshan").click(function(){
         	$(":checkbox:not(#fuxuan):checked").each(function(){
         			 $(this).parent().parent().parent().prev().remove(); 
         			 suan();
         			 shangp();
         	})
         });
         function shangp(){
         	var shang=0;
         	$(".dingd_s").each(function(i,dom){
         		var shp=$(dom).find(".button_z").val();
         		shang+=parseInt(shp);
         	})
         	$(".shul").text(shang);
         }
	}) 
